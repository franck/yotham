</div><!-- END W -->
</div><!-- END WRAPPER -->

<div id="footer">
&nbsp;		
</div>

</div><!-- END CONTAINER -->

<?php wp_footer(); ?>

</body>
</html>